package com.lnt.mvc.dao;

import java.util.List;

import com.lnt.mvc.model.Registration;

public interface RegistrationDao {
public void save(Registration r);
 //public List<String> fetchInstitutename();
}
