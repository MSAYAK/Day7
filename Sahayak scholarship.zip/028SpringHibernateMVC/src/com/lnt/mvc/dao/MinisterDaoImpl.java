package com.lnt.mvc.dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lnt.mvc.model.ScholarshipApplicationForm;

@Repository
public class MinisterDaoImpl implements MinisterDao{

@Autowired
private SessionFactory sessionFactory;
public void setSessionFactory(SessionFactory sf) {
this.sessionFactory = sf;
}
private static final Logger logger = 
LoggerFactory.getLogger(RegistrationDaoImpl.class);


@Override
public List<ScholarshipApplicationForm> listapplications() {
Session session = this.sessionFactory.openSession();
Transaction tx=session.beginTransaction();
String query="from ScholarshipApplicationForm";
Query q=session.createQuery(query);
List<ScholarshipApplicationForm> applicationList=q.list();
tx.commit();
session.close();
System.out.println(applicationList);
return applicationList;
 
}


@Override
public void acceptApplicaton(int studentId) {
Session session = this.sessionFactory.openSession();
Transaction tx=session.beginTransaction();
String query="update ScholarshipApplicationForm p  set p.requestStatus='ACCEPTED' where p.studentId=:studentId";
Query q=session.createQuery(query);
q.setInteger("studentId",studentId);
q.executeUpdate();
tx.commit();
Transaction tx1=session.beginTransaction();
String query1="insert into FinalApplication(studentId,studentName,instituteName,dob,emailId,mobileno,studentState,xMarks,xIIMarks,degreeMarks,familyAnnualIncome,caste) "
+ "select p.studentId,p.studentName,p.instituteName,p.dob,p.emailId,p.mobileno,p.studentState,p.xMarks,p.xIIMarks,p.degreeMarks,p.familyAnnualIncome,p.caste from ScholarshipApplicationForm p where p.requestStatus='ACCEPTED'"; 
Query q1=session.createQuery(query1);
q1.executeUpdate();
tx1.commit();
session.close();
}


@Override
public void rejectApplication(int studentId) {
Session session = this.sessionFactory.openSession();
Transaction tx=session.beginTransaction();
String query="update ScholarshipApplicationForm p set p.requestStatus='REJECTED' where p.studentId=:studentId";
Query q=session.createQuery(query);
q.setInteger("studentId",studentId);
q.executeUpdate();
tx.commit();
session.close();
}


@Override
public ScholarshipApplicationForm getApplication(int studentId) {
 
Session session = this.sessionFactory.openSession();
Transaction tx=session.beginTransaction();
String query="from ScholarshipApplicationForm where studentId=:studentId";
Query q=session.createQuery(query);
q.setInteger("studentId",studentId);
List<ScholarshipApplicationForm> applicationList=q.list();
tx.commit();
Iterator<ScholarshipApplicationForm> itr= applicationList.iterator();
ScholarshipApplicationForm scholarshipApplicationForm=new ScholarshipApplicationForm();
while(itr.hasNext())
{
scholarshipApplicationForm= (ScholarshipApplicationForm) itr.next();
}
return scholarshipApplicationForm;
 
}

 
}
