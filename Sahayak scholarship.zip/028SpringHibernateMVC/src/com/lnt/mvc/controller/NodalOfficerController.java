package com.lnt.mvc.controller;

 
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lnt.mvc.model.FinalApplication;

import com.lnt.mvc.model.ScholarshipApplicationForm;
import com.lnt.mvc.model.StudentRegistration;
import com.lnt.mvc.service.NodalOfficerService;
@Controller
public class NodalOfficerController {
@Autowired 
private NodalOfficerService nodalOfficerService;

public void setNodalOfficerService(NodalOfficerService nodalOfficerService) {
this.nodalOfficerService = nodalOfficerService;
}


@RequestMapping(value="/studentstatus1",method = RequestMethod.GET)
public String studentStatus(Model model,HttpSession session)
{
Integer studentId=(Integer)session.getAttribute("studentId");
System.out.println(studentId);
List<FinalApplication>finalApplication=this.nodalOfficerService.application();
System.out.println(finalApplication);
model.addAttribute("FinalApplications",finalApplication);
return "ViewStatus";
}






@RequestMapping(value="/presentstatus1", 
method = RequestMethod.POST)
public String addStudent(@ModelAttribute("scholarship") 
@Valid FinalApplication finalApplication, 
BindingResult result, 
Model model,HttpSession session) {
finalApplication.setRequestStatus("PENDING");
StudentRegistration r=(StudentRegistration)session.getAttribute("");
/*this.iFarmerService.addCrop(potentialcrop);*/
return "applicationstatus";

}



@RequestMapping(value="/statehome")
public String ministerlogin(Model model) {
	System.out.println("hello guyzz");
//model.addAttribute("minister",new MinisterLogin());
model.addAttribute("studentlists1",this.nodalOfficerService.application());
return "statehome";
}








@RequestMapping("/accept/{id}")
public String acceptStudent(
@PathVariable("id") int studentId,Model model) 
{
this.nodalOfficerService.acceptApplicaton(studentId); 
 
List<FinalApplication> finalApplications=this.nodalOfficerService.application();
model.addAttribute("ApplicationForms",finalApplications);
return "statedashboard";
}


@RequestMapping("/reject/{id}")
public String rejectStudent(
@PathVariable("id") int studentId,Model model) 
{
this.nodalOfficerService.rejectApplication(studentId);
List<FinalApplication>finalApplication=this.nodalOfficerService.application();
model.addAttribute("ApplicationForms",finalApplication);
return "statedashboard";
}



}